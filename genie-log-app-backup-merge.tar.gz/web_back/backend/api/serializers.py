from ..models import IndexMessage, Message, User, Group, Area
from rest_framework import serializers


class IndexMessageSerializer(serializers.ModelSerializer):
	class Meta:
		model = IndexMessage
		fields = ('title', 'content', 'created_on')


# USERS -----------------------------------------------------------------
class UserSerializerWithPassword(serializers.ModelSerializer):
	class Meta:
		model = User
		fields = ('name', 'password', 'email', 'photo', 'bio', 
				  'currentLocation', 'is_staff', 'is_active',
				  'date_joined')
class UserSerializer(serializers.ModelSerializer):
	class Meta:
		model = User
		fields = ('name', 'email', 'photo', 'bio', 'currentLocation',
				  'friendList', 'is_staff', 'is_active',
				  'date_joined')
class UserSerializerWithId(serializers.ModelSerializer):
	class Meta:
		model = User
		fields = ('id', 'name', 'email', 'photo', 'bio', 'currentLocation',
				  'friendList', 'is_staff', 'is_active',
				  'date_joined')


# MESSAGES -----------------------------------------------------------------
class MessageSerializer(serializers.ModelSerializer):
	class Meta:
		model = Message
		fields = ('sender', 'latitude',
				  'longitude', 'radius','visibility',
				  'content', 'created_on',
				  'updated_on', 'duration')

class MessageSerializerWithReceivers(serializers.ModelSerializer):
	class Meta:
		model = Message
		fields = ('id', 'sender', 'receivers', 'latitude',
				  'longitude', 'radius','visibility',
				  'content', 'created_on',
				  'updated_on', 'duration')

class MessageSerializerWithId(serializers.ModelSerializer):
	class Meta:
		model = Message
		fields = ('id', 'sender', 'receivers', 'latitude',
				  'longitude', 'radius','visibility',
				  'content', 'created_on',
				  'updated_on', 'duration')


# GROUP -----------------------------------------------------------------
class GroupSerializer(serializers.ModelSerializer):
	class Meta:
		model = Group
		fields = ('name', 'photo', 'admin', 'visibility')

class GroupSerializerWithId(serializers.ModelSerializer):
	class Meta:
		model = Group
		fields = ('id','name', 'photo', 'admin', 'visibility', 'users')

class GroupSerializerWithUsers(serializers.ModelSerializer):
	class Meta:
		model = Group
		fields = ('name', 'photo', 'admin', 'visibility', 'users')
class GroupSerializerOnlyUsers(serializers.ModelSerializer):
	class Meta:
		model = Group
		fields = ('users',)

# AREA -----------------------------------------------------------------
class AreaSerializer(serializers.ModelSerializer):
	class Meta:
		model = Area
		fields = ('name', 'latitude', 'longitude', 'radius', 'user')

class AreaSerializerWithId(serializers.ModelSerializer):
	class Meta:
		model = Area
		fields = ('id', 'name', 'latitude', 'longitude', 'radius', 'user')