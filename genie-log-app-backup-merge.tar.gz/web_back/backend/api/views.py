from ..models import IndexMessage, Message, Group, User, Visibility, Area
from .serializers import IndexMessageSerializer, MessageSerializer
from .serializers import MessageSerializer, MessageSerializerWithId
from .serializers import GroupSerializer, GroupSerializerWithId, GroupSerializerWithUsers, GroupSerializerOnlyUsers
from .serializers import UserSerializer, UserSerializerWithId, UserSerializerWithPassword
from .serializers import AreaSerializer, AreaSerializerWithId

from ..managers import UserManager

from rest_framework import generics, status
from rest_framework.response import Response
from django.utils import timezone
from math import sqrt

from django.views.generic import TemplateView
from django.contrib.auth import authenticate, login, logout

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated



class HelloView(APIView):
	"""
	Example api view (authenticated)
	TODO: Must be deleted before delivery
	"""
	permission_classes = (IsAuthenticated,)

	def get(self, request):
		content = {'message': 'Hello, World!'}
		return Response(content)


class IndexMessageListView(generics.ListAPIView):
	"""
	Example api view
	TODO: Must be deleted before delivery
	"""
	queryset = IndexMessage.objects.all()
	serializer_class = IndexMessageSerializer


class IndexMessageCreateView(generics.CreateAPIView):
	"""
	Example api view
	TODO: Must be deleted before delivery
	"""
	queryset = IndexMessage.objects.all()
	serializer_class = IndexMessageSerializer

	def create(self, request, *args, **kwargs):
		super(IndexMessageCreateView, self).create(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully created",
		            "result": request.data}
		return Response(response)


class IndexMessageDetailView(generics.RetrieveUpdateDestroyAPIView):
	"""
	Example api view
	TODO: Must be deleted before delivery
	"""
	queryset = IndexMessage.objects.all()
	serializer_class = IndexMessageSerializer

	def retrieve(self, request, *args, **kwargs):
		super(IndexMessageDetailView, self).retrieve(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully retrieved",
		            "result": data}
		return Response(response)

	def patch(self, request, *args, **kwargs):
		super(IndexMessageDetailView, self).patch(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully updated",
					"result": data}
		return Response(response)

	def delete(self, request, *args, **kwargs):
		super(IndexMessageDetailView, self).delete(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully deleted"}
		return Response(response)


# View classes for message CRUD
############################################
class ListNearMessages(generics.ListAPIView):
	"""
	List messages in a specific zone (latitude, longitude, radius)
	url : GET message/list/<lat>/<lon>/<rad>/
	"""
	serializer_class = MessageSerializer
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List near Messages
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""

		queryset = self.get_queryset(request)
		serializer = MessageSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)

	def get_queryset(self, request):
		"""
		Filter queryset around coordinates
		:return: queryset
		"""
		# 78.567 is equal to 1 degree on earth coordinates
		valueConversion = 78.567
		rad = float(self.kwargs['rad'])/valueConversion
		lat = float(self.kwargs['lat'])
		lon = float(self.kwargs['lon'])
		queryset = Message.objects.filter(
			latitude__lte=(lat+rad), latitude__gte=(lat-rad),
			longitude__lte=(lon+rad), longitude__gte=(lon-rad))
		queryset = self.exclude_on_duration(queryset)
		queryset = self.exclude_on_position(queryset, lat, lon, rad)
		group_queryset = self.filter_by_groups(request, queryset)
		public_queryset = self.filter_public_message(queryset)
		own_queryset = self.filter_own_message(request, queryset)
		final_queryset = group_queryset | public_queryset | own_queryset
		return final_queryset

	def exclude_on_duration(self, queryset):
		"""
		exclude message from a queryset if duration time is expired
		returns a new queryset filtered
		:param queryset:
		:return: returns a new queryset filtered
		"""
		excludes = []
		for message in queryset:
			if timezone.now() > message.created_on + message.duration:
				excludes.append(message.id)
		return queryset.exclude(id__in=excludes)

	def exclude_on_position(self, queryset, center_x, center_y, radius):
		"""
		exclude messages out of the circle defined by center_x,center_y,radius
		:param queryset:
		:param center_x:
		:param center_y:
		:param radius:
		:return: returns a new queryset filtered
		"""
		excludes = []
		for message in queryset:
			if self.is_message_out_of_circle(message, center_x, center_y, radius):
				excludes.append(message.id)
		return queryset.exclude(id__in=excludes)

	def is_message_out_of_circle(self, message, center_x, center_y, radius):
		"""
		Verify if a message is out of the circle defined by center_x,center_y,radius
		:param message:
		:param center_x:
		:param center_y:
		:param radius:
		:return:
		"""
		sq_distance = (message.latitude - center_x)**2 + (message.longitude - center_y)**2
		return sqrt(sq_distance) > radius

	def filter_by_groups(self, request, queryset):
		"""
		Filter queryset by user's groups
		:param request:
		:param queryset:
		:return: new queryset
		"""
		user_groups = request.user.group_set.all()
		return queryset.filter(receivers__in=user_groups)

	def filter_public_message(self, queryset):
		"""
		Keep only message with public visibility
		:param queryset:
		:return: new queryset
		"""
		public = Visibility.objects.get(name="Public")
		return queryset.filter(visibility=public)

	def filter_own_message(self, request, queryset):
		"""
		Keep only messages send by the user
		:param request:
		:param queryset:
		:return: new queryset
		"""
		return queryset.filter(sender=request.user)



class CreateMessage(generics.CreateAPIView):
	"""
	Create new message
	url : POST message/create/
	TODO: return receivers in response
	"""
	queryset = Message.objects.all()
	serializer_class = MessageSerializer
	permission_classes = (IsAuthenticated,)

	def create(self, request, *args, **kwargs):
		"""
		Create a new message
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		serializer = self.get_serializer(data=request.data)
		serializer.is_valid(raise_exception=True)

		if serializer.is_valid():
			message = Message.objects.create(**serializer.validated_data)
			message.save()
			group_pks = request.data["receivers"]
			for group_pk in group_pks:
				message.receivers.add( Group.objects.get(pk=int(group_pk)) )

			#Message_belong_group.objects.create(group=message.receiver, message=message)
			response = {"status_code": status.HTTP_200_OK,
		            	"message": "Successfully created",
		            	"result": serializer.data}
			return Response(response)


class ManageMessage(generics.RetrieveUpdateDestroyAPIView):
	"""
	Get (retrieve), update (patch) and delete (delete) a message depending on its id
	url : GET/PATCH/DELETE message/<int:pk>/
	"""
	queryset = Message.objects.all()
	serializer_class = MessageSerializer
	permission_classes = (IsAuthenticated,)

	def retrieve(self, request, *args, **kwargs):
		"""
		Get data of a message
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageMessage, self).retrieve(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully retrieved",
		            "result": data}
		return Response(response)

	def patch(self, request, *args, **kwargs):
		"""
		Patch data of a message
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		super(ManageMessage, self).patch(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully updated",
					"result": data}
		return Response(response)

	def delete(self, request, *args, **kwargs):
		"""
		Delete a message entry
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		super(ManageMessage, self).delete(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully deleted"}
		return Response(response)


# View classes for group CRUD
############################################
class CreateGroup(generics.CreateAPIView):
	"""
	Create new group
	url : POST group/create/
	"""

	queryset = Group.objects.all()
	serializer_class = GroupSerializer
	permission_classes = (IsAuthenticated,)

	def create(self, request, *args, **kwargs):
		"""
		Create Group and add request user's as admin
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		serializer = GroupSerializer(data=request.data)
		serializer.is_valid(raise_exception=True)

		if serializer.is_valid():
			group = Group.objects.create(**serializer.validated_data)
			group.save()
			group.users.add(request.user)

			response = {"status_code": status.HTTP_200_OK,
		            	"message": "Successfully created",
		            	"result": serializer.data}

			return Response(response)


class ManageGroup(generics.RetrieveUpdateDestroyAPIView):
	"""
	Get (retrieve), update (patch) and delete (delete) a group depending on its id
	url : GET/PATCH/DELETE group/<int:pk>/
	"""
	queryset = Group.objects.all()
	serializer_class = GroupSerializerWithId
	permission_classes = (IsAuthenticated,)

	def retrieve(self, request, *args, **kwargs):
		"""
		Get data of a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageGroup, self).retrieve(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data

		# replace visibility pk by name
		visibility_pk = int(data['visibility'])
		data['visibility'] = Visibility.objects.get(pk=visibility_pk).name

		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully retrieved",
		            "result": data}
		return Response(response)

	def patch(self, request, *args, **kwargs):
		"""
		Patch group only if request user's is admin
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		instance = self.get_object()
		if(instance.admin.pk == request.user.pk):
			serializer = self.get_serializer(instance)
			super(ManageGroup, self).patch(request, args, kwargs)
			data = serializer.data
			response = {"status_code": status.HTTP_200_OK,
			            "message": "Successfully updated",
						"result": data}
			return Response(response)
		else:
			response = {"status_code": status.HTTP_200_OK,
			            "message": "You are not admin of the group"
						}
			return Response(response)

	def delete(self, request, *args, **kwargs):
		"""
		Delete group entry
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		super(ManageGroup, self).delete(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully deleted"}
		return Response(response)


class AddGroupMembers(generics.RetrieveUpdateDestroyAPIView):
	"""
	Update (patch), add a group member
	url : PATCH group/members/add/<int:group_pk>/
	"""

	queryset = Group.objects.all()
	permission_classes = (IsAuthenticated,)

	def patch(self, request, *args, **kwargs):
		"""
		Add depending on existence a user from a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		serializer = GroupSerializerOnlyUsers(data=request.data)
		serializer.is_valid(raise_exception=True)
		group_pk = int(self.kwargs["group_pk"])
		group = Group.objects.get(id=group_pk)

		if serializer.is_valid():
			users = serializer.validated_data['users']
			for user in users:
				if not group.users.filter(id=user.id).exists():
					group.users.add(user)

			response = {"status_code": status.HTTP_200_OK,
						"message": "Successfully updated"}

			return Response(response)

class RemoveGroupMembers(generics.RetrieveUpdateDestroyAPIView):
	"""
	Update (patch), delete a group member
	url : PATCH group/members/remove/<int:group_pk>/
	"""

	queryset = Group.objects.all()
	permission_classes = (IsAuthenticated,)

	def patch(self, request, *args, **kwargs):
		"""
		Remove depending on existence a user from a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		serializer = GroupSerializerOnlyUsers(data=request.data)
		serializer.is_valid(raise_exception=True)
		group_pk = int(self.kwargs["group_pk"])
		group = Group.objects.get(id=group_pk)

		if serializer.is_valid():
			users = serializer.validated_data['users']
			for user in users:
				if group.users.filter(id=user.id).exists():
					group.users.remove(user)

			response = {"status_code": status.HTTP_200_OK,
						"message": "Successfully updated"}

			return Response(response)

class ListGroupsFromUser(generics.ListAPIView):
	"""
	List all groups of a user (user_pk)
	url : GET group/list/groups/<int:user_pk>/
	TODO: secure  User.objects.get(id=user_pk) if user_pk is unknow
	"""
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all groups of a user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		user_pk = int(self.kwargs['user_pk'])
		groups = User.objects.get(id=user_pk).users.all()
		serializer = GroupSerializerWithId(groups, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
				"message": "Successfully listed",
				"result": data}
		return Response(response)


class ListUsersFromGroup(generics.ListAPIView):
	"""
	List all users of a group (group_pk)
	url : GET group/list/users/<int:group_pk>/
	TODO: secure Group.objects.get(id=group_pk) if group_pk is unknow
	"""
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all users of a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		group_pk = int(self.kwargs['group_pk'])
		users = Group.objects.get(id=group_pk).users.all()
		serializer = UserSerializerWithId(users, many=True)
		data = serializer.data

		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)

class ListGroups(generics.ListAPIView):
	"""
	List all groups
	url : GET group/list/
	"""
	serializer_class = GroupSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all groups
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		queryset = Group.objects.all()
		serializer = GroupSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)

class ListPublicGroups(generics.ListAPIView):
	"""
	List all public groups
	url : GET group/list/public/
	"""
	serializer_class = GroupSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all public groups
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		queryset = Group.objects.filter(visibility=1)
		serializer = GroupSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)


class ListUnknowUsersFromGroup(generics.ListAPIView):
	"""
	List all users not known to a group (friends and group members exclusion)
	url : GET user/list/unknow/<int:user_pk>
	"""
	serializer_class = UserSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all users not known to a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		group_pk = int(self.kwargs['group_pk'])
		group_members = self.get_group_members(group_pk)
		queryset = User.objects.all().exclude(id__in=group_members)
		serializer = UserSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)

	def get_group_members(self, group_pk):
		members = Group.objects.get(id=group_pk).users.all()
		return [member.id for member in members]



class ListMessagesFromGroup(generics.ListAPIView):
	"""
	List all messages of a group (group_pk)
	url : GET group/list/messages/<int:group_pk>/
	TODO: secure Group.objects.get(id=group_pk) if group_pk is unknow
	"""
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all messages of a group
		:param request:
		:param args:
		:param kwargs:
		:return: JSON reponse with data
		"""
		group_pk = int(self.kwargs['group_pk'])
		messages = Group.objects.get(id=group_pk).receivers.all()
		serializer = MessageSerializerWithId(messages, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)


# View classes for User
############################################
class CurrentUserView(APIView):
	"""
	Get current user (logged)
	url: GET user/current/
	"""
	permission_classes = (IsAuthenticated,)

	def get(self, request):
		"""
		Get current user
		:param request:
		:return: JSON response with data
		"""
		serializer = UserSerializerWithId(request.user)
		return Response(serializer.data)


class CreateUser(generics.CreateAPIView):
	"""
	Create new User
	Insert admin user
	url : POST user/create/
	TODO : all of it
	"""

	queryset = User.objects.all()
	serializer_class = UserSerializerWithPassword
	permission_classes = []

	def create(self, request, *args, **kwargs):
		"""
		Create new User
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		serializer = self.get_serializer(data=request.data)
		serializer.is_valid(raise_exception=True)

		if serializer.is_valid():
			password = serializer.validated_data.pop('password')
			user = User.objects.create(**serializer.validated_data)
			user.set_password(password)
			user.save()

			response = {"status_code": status.HTTP_200_OK,
						"message": "Successfully created",
						"result": serializer.validated_data}

			return Response(response)


class ManageUser(generics.RetrieveUpdateDestroyAPIView):
	"""
	Get (retrieve), update (patch) and delete (delete) a group depending on its id
	url : GET/PATCH/DELETE user/<int:pk>/
	"""
	queryset = User.objects.all()
	serializer_class = UserSerializerWithId
	permission_classes = (IsAuthenticated,)

	def retrieve(self, request, *args, **kwargs):
		"""
		Get data of an user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageUser, self).retrieve(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully retrieved",
		            "result": data}
		return Response(response)

	def patch(self, request, *args, **kwargs):
		"""
		Patch data of an user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageUser, self).patch(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully updated",
		            "result": data}
		return Response(response)

	def delete(self, request, *args, **kwargs):
		"""
		Delete user entry
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageUser, self).delete(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully deleted"}
		return Response(response)


class ListUsers(generics.ListAPIView):
	"""
	List all groups
	url : GET user/list/
	"""
	serializer_class = UserSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		queryset = User.objects.all()
		serializer = UserSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)



class ListUnknowUsersFromUser(generics.ListAPIView):
	"""
	List all users not known to a user (friends and group members exclusion)
	url : GET user/list/unknow/<int:user_pk>
	"""
	serializer_class = UserSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all users not known to a user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		user_pk = int(self.kwargs['user_pk'])
		user_friends = self.get_user_friends(user_pk)
		queryset = User.objects.all().exclude(id__in=user_friends)
		serializer = UserSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)

	def get_user_friends(self, user_pk):
		"""
		returns all members known to a user (duplicates are possible - not an issue)
		"""
		queryset_friends = User.objects.get(id=user_pk).friendList.all()
		friends = [user_pk] + [friend.id for friend in queryset_friends]
		queryset_groups = User.objects.get(id=user_pk).groups.all()
		for group in queryset_groups:
			queryset_users_in_group = Group.objects.get(id=group.id).users.all()
			friends += [user.id for user in queryset_users_in_group]
		return friends


class ListAreasFromUser(generics.ListAPIView):
	"""
	List all areas of a user (user_pk)
	url : GET user/list/areas/<int:user_pk>/
	TODO: secure  User.objects.get(id=user_pk) if user_pk is unknow
	"""
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all areas of a user
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		user_pk = int(self.kwargs['user_pk'])
		areas = User.objects.get(id=user_pk).area_set.all()
		serializer = AreaSerializerWithId(areas, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
				"message": "Successfully listed",
				"result": data}
		return Response(response)


# View classes for area CRUD
############################################
class CreateArea(generics.CreateAPIView):
	"""
	Create new area
	url : POST group/create/
	"""
	queryset = Area.objects.all()
	serializer_class = AreaSerializer
	permission_classes = (IsAuthenticated,)

	def create(self, request, *args, **kwargs):
		"""
		Create Area
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		serializer = AreaSerializer(data=request.data)
		serializer.is_valid(raise_exception=True)

		if serializer.is_valid():
			area = Area.objects.create(**serializer.validated_data)
			area.save()

			response = {"status_code": status.HTTP_200_OK,
		            	"message": "Successfully created",
		            	"result": serializer.data}

			return Response(response)


class ManageArea(generics.RetrieveUpdateDestroyAPIView):
	"""
	Get (retrieve), update (patch) and delete (delete) an area depending on its id
	url : GET/PATCH/DELETE area/<int:pk>/
	"""
	queryset = Area.objects.all()
	serializer_class = AreaSerializerWithId
	permission_classes = (IsAuthenticated,)

	def retrieve(self, request, *args, **kwargs):
		"""
		Get data of an area
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response with data
		"""
		super(ManageArea, self).retrieve(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully retrieved",
		            "result": data}
		return Response(response)

	def patch(self, request, *args, **kwargs):
		"""
		Patch data of an area
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		super(ManageArea, self).patch(request, args, kwargs)
		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully updated",
					"result": data}
		return Response(response)

	def delete(self, request, *args, **kwargs):
		"""
		Delete an area entry
		:param request:
		:param args:
		:param kwargs:
		:return: JSON response
		"""
		super(ManageArea, self).delete(request, args, kwargs)
		response = {"status_code": status.HTTP_200_OK,
		            "message": "Successfully deleted"}
		return Response(response)

class ListAreas(generics.ListAPIView):
	"""
	List all areas
	url : GET 	area/list/
	"""
	serializer_class = GroupSerializerWithId
	permission_classes = (IsAuthenticated,)

	def list(self, request, *args, **kwargs):
		"""
		List all areas
		:param request:
		:param args:
		:param kwargs:
		:return: JSON Response with data
		"""
		queryset = Area.objects.all()
		serializer = AreaSerializerWithId(queryset, many=True)
		data = serializer.data
		response = {"status_code": status.HTTP_200_OK,
					"message": "Successfully listed",
					"result": data}
		return Response(response)



