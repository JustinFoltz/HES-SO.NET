from django.shortcuts import render, HttpResponse
from django.core import serializers
from .models import IndexMessage
