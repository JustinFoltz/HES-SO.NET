import datetime
import requests
import json

from django.shortcuts import render, HttpResponse, HttpResponseRedirect, reverse
from django.conf import settings
from django.views.generic import TemplateView
from django.template import RequestContext

from django.http.response import HttpResponseForbidden


backend = settings.APP_API_URL


class LoginView(TemplateView):
    """
    Login View view used to display the login page.
    """
    template_name = "auth/login.html"

    def get(self, request, *args, **kwargs):
        return super(LoginView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(LoginView, self).get_context_data(**kwargs)
        now = datetime.datetime.now()
        context['copy_year'] = now.year
        return context

    def post(self, request, **kwargs):
        context = super(LoginView, self).get_context_data(**kwargs)
        name = request.POST.get('username', False)
        password = request.POST.get('pass', False)
        data = {'name':name, 'password': password}
        response = requests.post(backend+'token/', data=data)

        if response.status_code == 200:
            jsonResponse = json.loads(response.text)
            context['access_token'] = jsonResponse['access']
            context['refresh_token'] = jsonResponse['refresh']
            #return render(self.request, "main/main.html", context)
            return HttpResponseRedirect(reverse('index'))

        context['error'] = "Authentication error"
        return render(self.request, "auth/login.html", context)


def refresh_token(request):
    """
    refresh an access token from refresh token
    :param request:
    :return:
    """
    URL = backend+'token/refresh/'

    try:
        response = requests.post(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)




# used to refresh token -> seems uselesss
""" def refresh_token(request):
     token = request.POST['refresh']
     data = {"refresh": request.POST['refresh']}
     response = requests.post(backend+'token/refresh/', data=data, allow_redirects=True)
     return HttpResponse(json.dumps(response.json()), content_type='application/json') """


class RegisterView(TemplateView):
    """
    Register View view used to display the register page..
    """
    template_name = "auth/signup.html"

    def get(self, request, *args, **kwargs):
        return super(RegisterView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(RegisterView, self).get_context_data(**kwargs)
        now = datetime.datetime.now()
        context['copy_year'] = now.year
        return context

    def post(self, **kwargs):
        return render(self.request, "auth/signup.html")


class ForgotPassView(TemplateView):
    """
    View used to regenerate password
    """
    template_name = "auth/forgot.html"

    def get(self, request, *args, **kwargs):
        return super(ForgotPassView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(ForgotPassView, self).get_context_data(**kwargs)
        now = datetime.datetime.now()
        context['copy_year'] = now.year
        return context

    def post(self, **kwargs):
        print(kwargs)
        return render(self.request, "auth/signup.html")


class MainPageView(TemplateView):
    """
    View used to display the main page
    """
    template_name = "main/main.html"

    def get(self, request, *args, **kwargs):
        return super(MainPageView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(MainPageView, self).get_context_data(**kwargs)
        now = datetime.datetime.now()
        context['copy_year'] = now.year
        return context


# used to create message in backend
""" def sendMessage(request):
    #user =
    group = request.POST['group']
    area = request.POST['area']
    radius = request.POST['radius']
    content = request.POST['content']
    visibility = request.POST['visibility']

    return render(request, "home.html") """


# Users ----------------------------------------------------------------------------------------------------------------
def get_users(request):
    """
    get_user
    :param request:
    :return:
    """
    URL = backend+'user/list/'
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_unknow_users_from_user(request, **kwargs):
    """
    get unknow users to u user
    :param request:
    :return:
    """
    URL = backend+'user/list/unknow/' + str(kwargs["user_pk"]) + "/"
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_unknow_users_from_group(request, **kwargs):
    """
    get unknow users to u user
    :param request:
    :return:
    """
    URL = backend+'group/list/unknow_users/' + str(kwargs["group_pk"]) + "/"
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_current_user(request):
    """
    get current user
    :param request:
    :return:
    """
    URL = backend+'user/current/'

    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


# Groups ---------------------------------------------------------------------------------------------------------------
def get_groups(request):
    """
    Get groups by user
    :param request:
    :return:
    """
    URL = backend + 'group/list/'

    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_public_groups(request):
    """
    Get groups by user
    :param request:
    :return:
    """
    URL = backend + 'group/list/public'
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)

def get_groups_belong_to_user(request, **kwargs):
    """
    Get groups of a specific user
    :param request:
    :return:
    """
    URL = backend + 'group/list/groups/' + str(kwargs["user_pk"])

    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_group(request, **kwargs):
    """
    Get a specific group
    :param request:
    :return:
    """
    URL = backend + 'group/' + str(kwargs["group_pk"]) + "/"

    try:
        if request.method == 'GET':
            response = requests.get(URL, headers=request.headers, allow_redirects=True)
        if request.method == 'POST':
            response = requests.patch(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        if request.method == 'DELETE':
            response = requests.delete(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)

""" def add_remove_group_member(request, **kwargs):
    Add or remove a user from a group
    :param request:
    :return:
    URL = backend + 'group/' + str(kwargs["group_pk"]) + "/" + str(kwargs["user_pk"])
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status) """

def add_remove_group_member(request, **kwargs):
    """
    Add or remove a user from a group
    :param request:
    :return:
    """
    URL = backend + 'group/members/' + str(kwargs["group_pk"]) + "/"

    try:
        if request.method == 'POST':
            response = requests.patch(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)

def get_users_belong_to_group(request, **kwargs):
    """
    Get list of users belonging to a specific group
    :param request:
    :return:
    """
    URL = backend + 'group/list/users/' + str(kwargs["group_pk"])
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_messages_belong_to_group(request, **kwargs):
    """
    Get list of messages belonging to a specific group
    :param request:
    :return:
    """
    URL = backend + 'group/list/messages/' + str(kwargs["group_pk"])
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)

def create_group(request):
    """
    Create a group
    :param request
    """
    URL = backend + 'group/create/'
    try:
        response = requests.post(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


# Messages -------------------------------------------------------------------------------------------------------------

def create_message(request):
    """
    Create message
    :param request:
    :return:
    """
    URL = backend + 'message/create/'
    try:
        response = requests.post(URL, headers=request.headers, data=request.POST, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


def get_messages_in_circle(request, **kwargs):
    """
    Get list of messages in a circle defined by lat, lon, rad
    :param request:
    :return:
    """
    URL = backend + 'message/list/' + str(kwargs["lat"]) + '/' + str(kwargs["lat"]) + '/' + str(kwargs["rad"])
    try:
        response = requests.get(URL, headers=request.headers, allow_redirects=True)
        response.raise_for_status()
        return HttpResponse(json.dumps(response.json()), content_type='application/json')
    except requests.exceptions.HTTPError as err:
        status = err.response.status_code
        reason = err.response.reason
        return HttpResponse(reason, status=status)


# Exception Handlers ---------------------------------------------------------------------------------------------------
def handler400(request, exception):
    """
    View used to override 400 default page provided by Django
    :param request:
    :param exception:
    :return:
    """
    context = RequestContext(request)
    err_code = 400
    response = render('400.html', {"code": err_code, "error_raised": exception}, context)
    response.status_code = 400
    return response


def handler401(request, exception):
    """
    View used to override 401 default page provided by Django
    :param request:
    :param exception:
    :return:
    """
    context = RequestContext(request)
    err_code = 401
    response = render('401.html', {"code": err_code, "error_raised": exception}, context)
    response.status_code = 401
    return response


def handler403(request, exception):
    """
    View used to override 403 default page provided by Django
    :param request:
    :param exception:
    :return:
    """
    context = RequestContext(request)
    err_code = 400
    response = render('403.html', {"code": err_code, "error_raised": exception}, context)
    response.status_code = 400
    return response


def handler404(request, exception):
    """
    View used to override 404 default page provided by Django
    :param request:
    :param exception:
    :return:
    """
    context = RequestContext(request)
    err_code = 404
    response = render('400.html', {"code": err_code, "error_raised": exception}, context)
    response.status_code = 404
    return response


def handler500(request):
    """
    View used to override 500 default page provided by Django
    :param request:
    :param exception:
    :return:
    """
    context = RequestContext(request)
    err_code = 500
    response = render('500.html', {"code": err_code}, context)
    response.status_code = 500
    return response
