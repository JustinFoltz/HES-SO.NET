from django.urls import path, re_path
from . import views

app_name = 'frontend'

# Error handler
handler400 = 'frontend.views.handler400'
handler403 = 'frontend.views.handler403'
handler404 = 'frontend.views.handler404'
handler500 = 'frontend.views.handler500'

urlpatterns = [
    # Auth pages
    path('', views.LoginView.as_view(), name='login'),
    path('signup', views.RegisterView.as_view(), name='signup'),
    path('forgot_pass', views.ForgotPassView.as_view(), name='forgot_password'),
    path('refresh_token', views.refresh_token, name='refreshToken'),

    # Classic pages
    path('main', views.MainPageView.as_view(), name='index'),
    path('notifications', views.MainPageView.as_view(), name='notification'),
    path('friends', views.MainPageView.as_view(), name='friends'),
    path('profile', views.MainPageView.as_view(), name='profile'),
    #path('sendMessage', views.sendMessage, name='sendMessage'),

    # Group methods
    path('group/list', views.get_groups, name='getGroups'),
    path('group/list/public', views.get_public_groups, name='getPublicGroups'),
    path('group/list/user/<int:user_pk>', views.get_groups_belong_to_user, name='getGroupsBelongToUser'),
    path('group/<int:group_pk>', views.get_group, name='getGroup'),
    path('user/list/group/<int:group_pk>', views.get_users_belong_to_group, name='getUsersBelongToGroup'),
    path('group/list/messages/<int:group_pk>', views.get_messages_belong_to_group, name='getMessagesBelongToGroup'),
    #path('group/<int:group_pk>/<int:user_pk>', views.add_remove_group_member, name='add_remove_group_member'),
    path('group/create', views.create_group, name="createGroup"),
    path('group/members/<int:group_pk>', views.add_remove_group_member, name='add_remove_group_member'),
    path('group/list/unknow_users/<int:group_pk>', views.get_unknow_users_from_group, name='getUnknowUsersFromGroup'),

    # User methods
    path('user/current', views.get_current_user, name='getCurrentUser'),
    path('user/list', views.get_users, name='getUsers'),
    path('user/list/unknow_users/<int:user_pk>', views.get_unknow_users_from_user, name='getUnknowUsersFromUser'),

    # Messages methods
    path('message/create', views.create_message, name='createMessage'),
    re_path(r'message/list/(?P<lat>[0-9]+(.[0-9]+)?)/(?P<lon>[0-9]+(.[0-9]+)?)/(?P<rad>[0-9]+(.[0-9]+)?)/', views.get_messages_in_circle, name='getMessagesInCircle'),



]
