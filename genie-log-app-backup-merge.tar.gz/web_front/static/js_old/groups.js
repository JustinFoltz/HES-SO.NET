function getUserList(){
    let URL = '/user/list';

        $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data.result;
            let $el = $("#search-content");
            //console.log("MSG", msg);
            $el.empty(); // remove old options
            msg.forEach(function(item){
               $el.append($("<a>"+ item.name +"</a>").attr("href", item.id));
            });
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else
                alert( "Bad request !" );
        },
        fail: () => {
            alert( "Server unreachable !" );
        }
    });
}
getUserList();

function getGroupList(){
    let URL = '/group/list';

        $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data.result;
            let $el = $("#group-listing");
            //console.log("MSG", msg);
            $el.empty(); // remove old options
            msg.forEach(function(item){
               $el.append($("<option></option>").attr("value", item.id).text(item.name));
            });
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else 
                alert( "Bad request !" );
        },
        fail: () => {
            alert( "Server unreachable !" );
        }
    });
}

// Calling getGroup to populate dynmically all group forms
getGroupList();

/**
 * Get all the groups that a user belongs to
 * @param userID
 */
function getGroups(userID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/groups/' + userID;
            let URL = "/group/list/user/" + userID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);    
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )
}


/**
 * Get all public groups (temporary)
 */
function getPublicGroups(){
    return new Promise(
        resolve => {
            let URL = "/group/list/public";

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);    
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )
}

/**
 * Get information about a specific group
 * @param groupID
 */
function getOneGroup(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/' + groupID;
            let URL = "/group/" + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Get list of group members
 * @param groupID
 */
function getGroupMembers(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/users/' + groupID;
            let URL = 'user/list/group/' + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Get list of group messages
 * @param groupID
 */
function getGroupMessages(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/messages/' + groupID;
            let URL = 'group/list/messages/' + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Join a group
 * @param groupID
 */
function joinGroup(userID, groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/messages/' + groupID;
            let URL = 'group/' + groupID;

            $.ajax( {
                type: "POST",
                url: URL,
                data: {'users': userID},
                headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )  
}


async function updateUserGroups(userID) {
    let groups = await getGroups(userID);
    let listGroups = "";
    groups.forEach((group) => {
        listGroups += formatGroup(group)
    });
    $("#btn-group").attr('data-content', listGroups);
}


/**
 * Format a group
 * @param group 
 */
const formatGroup = (group) => {
    return `
    <div class="card text-center group-card">
        <h5 class="card-header">${group.name}</h5>
        <div class="card-body">
            <a href="#" id="group-see-group-btn" class="btn-small" data-groupid="${group.id}">See group</a>
        </div>
    </div>
    `
};

/**
 * Format a group for join modalq
 * @param group 
 */
const formatJoinGroup = (group) => {
    return `
    <div class="card text-center group-card">
        <h5 class="card-header">${group.name}</h5>
        <div class="card-body">
            <a href="#" id="group-join-group-btn" class="btn-small" data-groupid="${group.id}">Join group</a>
        </div>
    </div>
    `
};

/**
 * Format a member
 * @param member 
 */
const formatMember = (member) => {
    return `
        <div class="card group-card">
            <div class="card-body">
                <p>${member.name}</p>
            </div>
        </div>
    `
};

/**
 * Format the group messages
 * @param messages
 * @returns {string}
 */
const formatGroupMessage = (message) => {
    return `
        <div class="card group-card">
            <div class="card-header">
                <b>From : </b>${message.sender}
            </div>
            <div class="card-body">
                <p>${message.content}</p>
            </div>
        </div>
    `
};

/**
 * Fill the group modal with info about the group
 * @param group 
 */
async function fillGroupModal(groupID){
    let groupInfo = await getOneGroup(groupID);
    let groupMembers = await getGroupMembers(groupID);
    let groupMembersFormatted = groupMembers.reduce((out, x) => out += formatMember(x), "");
    
    $("#group-name").html(groupInfo.name);
    $("#group-visibility").html(groupInfo.visibility);
    $("#group-members").html(groupMembersFormatted);

    let groupMessages = await getGroupMessages(groupID);
    let groupMessagesFormatted = groupMessages.reduce((out, x) => out += formatGroupMessage(x), "");

    console.log(groupMessagesFormatted);
    $("#group-messages").html(groupMessagesFormatted);
}

/*
 * Authorize data-attribute in sanitizer whitelist
 */
$.fn.tooltip.Constructor.Default.whiteList['*'].push('data-groupid');

/*
 * Activate popover and html nesting
 */
$("[data-toggle=popover]")
    .popover({
        html: true,
        title: "<a class='add-group-btn' href='#'><img src='../../static/img/add-button.png'></a>" +
                "&nbsp<a class='join-group-btn' href='#'><img src='../../static/img/join-button.png'></a>"
                 
    });

/*
 * Show group modal on click and hide popover
 */
$(document).on('click', "#group-see-group-btn", function(e){
    let groupID = String( e.target.getAttribute('data-groupid'));
    fillGroupModal(groupID);
    $("#modal-see-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});


/*
 * Join group 
 */
$(document).on('click', "#group-join-group-btn", async function(e){
    let userID = 1;
    let groupID = String( e.target.getAttribute('data-groupid'));
    let response = await joinGroup(userID, groupID)
    $("#modal-join-group").modal('hide');
    updateUserGroups(userID);
});

/**
 * Insert data in group on page load
 */
$(document).ready(async function(){
    let userID = 1; // Needs to be changed once we have a system to know the userID of current user
    let groups = await getGroups(userID);
    let listGroups = "";
    groups.forEach((group) => {
        listGroups += formatGroup(group)
    });
    $("#btn-group").attr('data-content', listGroups);
});

/**
 * Show create group modal on click + and hide popover
 */
$(document).on("click", ".add-group-btn", () => {
    $("#modal-post-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});

/**
 * Show join group list modal on click + and hide popover
 */
$(document).on("click", ".join-group-btn", async function() {
    let publicGroups = await getPublicGroups();
    let listPublicGroups = "";
    publicGroups.forEach((publicGroup) => {
        listPublicGroups += formatJoinGroup(publicGroup)
    });
    $("#modal-join-group").find(".modal-body").html(listPublicGroups);
    $("#modal-join-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});

/**
 * Display an alert message on the main screen
 * @param {*} message 
 */
function showAlert(message){
    $(".alert-container").prepend(
        `
        <div id="alert-err" class="alert alert-danger alert-dismissible fade show" role="alert">
            <span class="alert-body">${message}</span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        `
    );
    $(".alert-container .alert").first().delay(2000).fadeOut(1000, function () { $(this).remove(); });
}

/*
 [ Utils ] -------------------------------------------------------------------------------------
 */

/**
 * When the user clicks on the button, toggle between hiding and showing the dropdown content
 */
function btn_showUserList() {
    document.getElementById("group_users_list").classList.toggle("show");
}

/**
 * Function used to filter dropdown search
 */
function filterUserFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("group_search");
    filter = input.value.toUpperCase();
    div = document.getElementById("search-content");
    a = div.getElementsByTagName("a");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
}