/**
 * Display an alert message on the main screen
 * @param {*} message 
 */

// function showAlert(message){
//     $(".alert-container").prepend(
//         `
//         <div id="alert-err" class="alert alert-danger alert-dismissible fade show" role="alert">
//             <span class="alert-body">${message}</span>
//             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
//                 <span aria-hidden="true">&times;</span>
//             </button>
//         </div>
//         `
//     );
//     $(".alert-container .alert").first().delay(2000).fadeOut(1000, function () { $(this).remove(); });
// }

// export { showAlert };