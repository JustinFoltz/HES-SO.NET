// import { showAlert } from "./utils.js";

/**
 * Global variables
 */
var positionMarker = {};
var accuracyAreaZone = {};
var areaVisibilityMessage = {};
var msgPosition = {};
var defaultRadius = 5;
var defaultDuration = 1;

var locateIcon = L.icon({
    iconUrl: '../static/img/locateIcon.png',

    iconSize:     [20, 20], // size of the icon
    shadowSize:   [0, 0], // size of the shadow
    iconAnchor:   [10, 10], // point of the icon which will correspond to marker's location
    shadowAnchor: [0, 0],  // the same for the shadow
    popupAnchor:  [0, 0] // point from which the popup should open relative to the iconAnchor
});

var markersCluster = new L.MarkerClusterGroup();

/**
 * Setting up the map
 */
let map = L.map('map').setView([46.2, 6.1667], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Disable the zoom when user double click on the map
map.doubleClickZoom.disable();

/**
 * Add a marker to the map
 * @param latitude : latitude of the marker
 * @param longitude : longitude of the marker
 * @param content : content to be dispplay when marker pops up
 */
const addMarker = (latitude, longitude, content) => {
    var options = {
        "maxWidth" : "500",
    };
    markersCluster.addLayer(
        new L.marker([latitude, longitude]).bindPopup(content, options)
    );
};

/**
 * Format comments so they can be placed in a popup
 * @param message
 * @returns {string}
 */
function formatComments(message){
    if (message === undefined){
        return "";
    }
    return message.map(x => {
        return `
    <div class="card text-center bg-light mb-3">
        <div class="card-header">
            <b>Message from : </b>${x.sender}
        </div>
        <div class="card-body">
            <p>${x.content}</p>
        </div>
    </div>
        `
    }).join(" ");
}

/**
 * Format a message so it can be placed in a popup
 * @param message
 * @returns {string}
 */
const formatMessage = (message) => {
    return `
        <div class="card text-center bg-light mb-3">
            <div class="card-header">
                <b>Message from : </b>${message.sender}
            </div>
            <div class="card-body">
                <p>${message.content}</p>
            </div>
            <div class="card-footer ">
                <div class="comments-title">
                    <b>Comments :</b><br>
                </div>` +
                formatComments(message.comment) + `
            </div>
        <div>
        `
    ;
};


/**
 * Try to find the location of the user oh the map and add a marker on it if it founds
 */
function geoloc(radius){
    var geoSuccess = function(position) {
        startPos = position;
        userlat = startPos.coords.latitude;
        userlon = startPos.coords.longitude;
        console.log("lat: "+userlat+" - lon: "+userlon);
        map.setView([userlat, userlon], 100/Math.log(startPos.coords.accuracy));
        if (positionMarker != undefined) {
              map.removeLayer(positionMarker);
              map.removeLayer(accuracyAreaZone);
              map.removeLayer(areaVisibilityMessage);
        }

        positionMarker = new L.marker([userlat, userlon], {icon:locateIcon}).bindPopup("You are next to here");
        accuracyAreaZone = L.circle([userlat, userlon], {radius: startPos.coords.accuracy, color:"#4b2354"});
        areaVisibilityMessage = L.circle([userlat, userlon], {radius: radius*1000, color:"#7386D5"});

        map.addLayer(positionMarker);
        map.addLayer(accuracyAreaZone);
        map.addLayer(areaVisibilityMessage);

        // Get all message after geoloc
        getMessage(userlat,userlon,radius);

    };
    var geoFail = function(){
        console.log("User doesn't allow the app to locate him");
    };
    navigator.geolocation.getCurrentPosition(geoSuccess,geoFail);
}

L.easyButton('<span class="target">&target;</span>', function(btn, map){
    geoloc(defaultRadius);
}).addTo(map);


/**
 * Send a POST to the API with the message and add marker on the map
 * @param message
 */
function postMessage(message){
    //let URL = 'http://localhost:8001/api/v1/message/create/';
    console.log(message);
    let URL = 'message/create';
    //let csrf = getCookie('csrftoken')

    $.ajax( {
        type: "POST",
        url: URL,
        data: message,
        headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
        success: (data) => {
            console.log("DATA", data);
            let msg = data.result;
            addMarker(msg.latitude, msg.longitude, formatMessage(msg));
            $("#modal-post-msg").modal('hide');
            clearModal();
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else 
                alert( "Bad request !" );
        },
        fail: () => {
            alert( "Server unreachable !" );
        }
    });
}

/**
 * Reset the different value of the message modal
 */
function clearModal(){
    $("#create_message")[0].reset();
    $("label[for='radius']").text(defaultRadius);
    $("label[for='duration']").text(defaultDuration);
    if($("#content").hasClass("is-invalid")){
        $("#content").removeClass("is-invalid");
    }
}

/**
 * Show modal form for message creation
 */
map.on('dblclick', function(e){
    $("#modal-post-msg").modal('show');
    msgPosition = e.latlng;
});


/**
 * Post message on form submit
 */
$("#create_message").submit( () => {
    if($("#content").val().length > 0){
        postMessage(
            {
                "sender": 1 ,
                "receivers": 1,
                "latitude": msgPosition.lat,
                "longitude": msgPosition.lng,
                "radius": $("#radius").val(),
                "content": String( $("#content").val() ),
                "visibility": 1,
                "duration": String( $("#duration").val() )
            }
        )
    }
    else{
        $("#content").addClass("is-invalid");
    }

    // Prevent page from reloading
    return false;
});

/**
 * Change the value of the radius slider
 */
$("#radius").on('input', () => {
    inputValue = $('#radius').val()
    $("label[for='radius']").text(inputValue);
});

/**
 * Change the value of the duration slider
 */
$("#duration").on('input', () => {
    inputValue = Math.round($('#duration').val() / 60)
    $("label[for='duration']").text(inputValue);
});

/**
 * Get all messages and add markers for a given position
 * @param lat
 * @param long
 * @param radius
 */
function getMessage(lat, long, radius){
    let URL = 'http://localhost:8001/api/v1/message/list/'+lat+'/'+long+'/'+radius;

    $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data.result;
            // console.log(msg);
            msg.forEach(function(item) {
                addMarker(item.latitude, item.longitude, formatMessage(item));
            });
        },
        error: (res) => {
            if(res.status == 401)
                showAlert("You're not authenticated");

            else 
                alert( "Bad request !" );
        },
        fail: () => {
            alert( "Server unreachable !" );
        }
    });
}

// TODO: Must be removed after tests
getMessage(46.2,6.1,20.0);

map.addLayer(markersCluster);

/**
 * Display an alert message on the main screen
 * @param {*} message 
 */
function showAlert(message){
    $(".alert-container").prepend(
        `
        <div id="alert-err" class="alert alert-danger alert-dismissible fade show" role="alert">
            <span class="alert-body">${message}</span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        `
    );
    $(".alert-container .alert").first().delay(2000).fadeOut(1000, function () { $(this).remove(); });
}

/**
 * Top bar
 */
function getCurrentUser(){
    let URL = 'user/current';

        $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data;
            //console.log(data);
            let $el = $("#top-profile");
            $el.empty();
            $el.append($("<span>"+msg.name+"</span>"));

            $el = $("#top-email");
            $el.empty();
            $el.append($("<span>" + msg.email+"</span>"));
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else
                alert( "Bad request !" );
        },
        fail: () => {
            alert( "Server unreachable !" );
        }
    });
}
getCurrentUser();