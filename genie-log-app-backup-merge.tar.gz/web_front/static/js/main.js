/*
    Number in the slider bubble
*/
var slider= document.getElementById("sliderRange");
var val = document.getElementById("valueRadius");
val.innerHTML = slider.value;
slider.oninput=function(){
  val.innerHTML=this.value;
};