
//[ INIT ]-------------------------------------------------------------------------

let currentUser = null;
let userGroups = null;

async function init() {
    currentUser = await getCurrentUser();
    await updateUserGroups();
} 
init();

/*
 * Update all groups lists of user interface
 * @param {*} userID 
 */
async function updateUserGroups() {
    userGroups = await getGroups(currentUser.id);
    fillGroupIconList();
    fillGroupMessageList();
}

/**
 * Fill group list of bottom icon
 */
function fillGroupIconList() {
    let listGroups = "";
    userGroups.forEach(group => { listGroups += formatGroup(group)});
    $("#btn-group").attr('data-content', listGroups);
}

/**
 * Fill group list of message
 */
function fillGroupMessageList() {
    let $el = $("#group-listing");
    $el.empty(); // remove old options
    userGroups.forEach(function(item){
        $el.append($("<option></option>").attr("value", item.id).text(item.name));
    });
}

/**
 * Return gourp info of a user group
 * @param {*} groupID 
 */
function getInfoUserGroup( groupID ) {
    return userGroups.find( group => group.id == groupID );
}


/* function getUserList(){
    let URL = '/user/list';

        $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data.result;
            let $el = $("#search-content");
            $el.empty(); // remove old options
            msg.forEach(function(item){
               $el.append($("<a>"+ item.name +"</a>").attr("href", item.id));
            });
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else
                showAlert( "Bad request !" );
        },
        fail: () => {
            showAlert( "Server unreachable !" );
        }
    });
}
getUserList(); */


//[ CALLS ] -------------------------------------------------------------------------------------


/**
 * Return list of users not contain in a group
 * @param {*} groupID 
 */
function getUnknowUserListFromGroup(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/groups/' + userID;
            let URL = 'group/list/unknow_users/' + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);    
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
        }
    )
}

/**
 * Delete a group
 * @param {*} groupID 
 */
function deleteGroup(groupID) {
    return new Promise(
        resolve => {
            let URL = 'group/' + groupID;
            $.ajax( {
                type: "DELETE",
                url: URL,
                headers: getCsrfAccessHeaders('application/json'),
                success: (data) => {
                    resolve(data.result); 
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
    });
}


/**
 * Add (or remove if present) a user to a group
 * @param {*} groupID 
 * @param {*} userList 
 */
function addRemoveUsersFromGroup(groupID, userID) {
    return new Promise(
        resolve => {
            let URL = 'group/members/' + groupID;
            $.ajax( {
                type: "POST",
                url: URL,
                data: {"users": userID},
                headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
                success: (data) => {
                    resolve(data.result); 
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        alert( "Bad request !" );
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
    });
}

/**
 * Modify a group
 * @param {*} groupID 
 * @param {*} userList 
 */
function patchGroup(groupID, data) {
    return new Promise(
        (resolve, reject) => {
            let URL = 'group/' + groupID;
            $.ajax( {
                type: "POST",
                url: URL,
                data: data,
                headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
                success: (data) => {
                    resolve(data.result); 
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else if(res.status == 400)
                        reject("Bad request");
                    else 
                        alert("server error");
                },
                fail: () => {
                    alert( "Server unreachable !" );
                }
            });
    });
}


/**
 * Get all app groups
 */
/* function getGroupList(){

    let URL = '/group/list';

        $.ajax( {
        type: "GET",
        url: URL,
        headers: getAccessHeaders("application/json"),
        success: (data) => {
            let msg = data.result;
            let $el = $("#group-listing");
            $el.empty(); // remove old options
            msg.forEach(function(item){
            $el.append($("<option></option>").attr("value", item.id).text(item.name));
            });
        },
        error: (res, status, err) => {
            if(res.status == 401)
                showAlert("You're not authenticated");
            else 
                showAlert( "Bad request !" );
        },
        fail: () => {
            showAlert( "Server unreachable !" );
        }
    });
}

// Calling getGroup to populate dynmically all group forms
getGroupList(); */



/**
 * Get all the groups that a user belongs to
 * @param userID
 */
function getGroups(userID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/groups/' + userID;
            let URL = "/group/list/user/" + userID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);    
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )
}


/**
 * Get all public groups (temporary)
 */
function getPublicGroups(){
    return new Promise(
        resolve => {
            let URL = "/group/list/public";

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);    
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )
}

/**
 * Get information about a specific group
 * @param groupID
 */
function getOneGroup(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/' + groupID;
            let URL = "/group/" + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Get list of group members
 * @param groupID
 */
function getGroupMembers(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/users/' + groupID;
            let URL = 'user/list/group/' + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Get list of group messages
 * @param groupID
 */
function getGroupMessages(groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/messages/' + groupID;
            let URL = 'group/list/messages/' + groupID;

            $.ajax( {
                type: "GET",
                url: URL,
                headers: getAccessHeaders("application/json"),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Join a group
 * @param groupID
 */
function joinGroup(userID, groupID){
    return new Promise(
        resolve => {
            //let URL = 'http://localhost:8001/api/v1/group/list/messages/' + groupID;
            let URL = 'group/members/' + groupID;

            $.ajax( {
                type: "POST",
                url: URL,
                data: {'users': userID},
                headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
                success: (data) => {
                    resolve(data.result);
                },
                error: (res, status, err) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert( "Bad request !" );
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )  
}

/**
 * Create a group
 * @param name: Group name
 * @param admin: Group admin
 * @param visibility: Group visibility
 */
function createGroup(name, admin, visibility){
    return new Promise(
        resolve => {
            let URL = 'group/create';

            $.ajax( {
                type: "POST",
                url: URL,
                data: {
                    'name': name,
                    'admin': admin,
                    'visibility': visibility
                },
                headers: getCsrfAccessHeaders('application/x-www-form-urlencoded; charset=UTF-8'),
                success: (data) => {
                    // console.log(data);
                },
                error: (res) => {
                    if(res.status == 401)
                        showAlert("You're not authenticated");
                    else 
                        showAlert("Bad request");
                },
                fail: () => {
                    showAlert( "Server unreachable !" );
                }
            });
        }
    )
}

/**
 * Get the current user
 */
function getCurrentUser(){
    return new Promise(
        resolve => {
            let URL = 'user/current';

            $.ajax( {
            type: "GET",
            url: URL,
            headers: getAccessHeaders("application/json"),
            success: (data) => {
                resolve(data);
            },
            error: (res) => {
                if(res.status == 401)
                    showAlert("You're not authenticated");
                else
                    showAlert( "Bad request !" );
            },
            fail: () => {
                showAlert( "Server unreachable !" );
            }
            });
        }
    )
}



//[ FORMATS ] --------------------------------------------------------------------------------------------------


/**
 * Format a group
 * @param group 
 */
const formatGroup = (group) => {
    return `
    <div class="card text-center group-card">
        <h5 class="card-header">${group.name}</h5>
        <div class="card-body">
            <a href="#" id="group-see-group-btn" class="btn-small" data-groupid="${group.id}">See group</a>
        </div>
    </div>
    `
};

/**
 * Format a group for join modalq
 * @param group 
 */
const formatJoinGroup = (group) => {
    return `
    <div class="card text-center group-card">
        <h5 class="card-header">${group.name}</h5>
        <div class="card-body">
            <a href="#" id="group-join-group-btn" class="btn-small" data-groupid="${group.id}">Join group</a>
        </div>
    </div>
    `
};

/**
 * Format a member
 * @param member 
 */
const formatMember = (member) => {
    return `
        <div class="card group-card">
            <div data-userid="${member.id}" class="card-body member-item">
                <p>${member.name}</p>
            </div>
        </div>
    `
};

/**
 * Format the group messages
 * @param messages
 * @returns {string}
 */
const formatGroupMessage = (message) => {
    return `
        <div class="card group-card">
            <div class="card-header">
                <b>From : </b>${message.sender}
            </div>
            <div class="card-body">
                <p>${message.content}</p>
            </div>
        </div>
    `
};

/**
 * format the users list for invitation 
 * @param {*} groupID 
 * @param {*} userList 
 */
function formatInvitUserList(groupID, userList) {
    let $el = $("#search-invit-content");
    $el.attr("data-usergroup", groupID);
    $el.empty();
    userList.forEach( function(user){   
        $el.append(`
            <button class="list-group-item list-group-item-action item-user-invit-list" 
            data-userid="${user.id}">${user.name}</button>
        `);
    });
}

//[ GROUP ] -------------------------------------------------------------------------------

/**
 * Fill the group modal with info about the group
 * @param group 
 */
async function fillGroupModal(groupID){

    $('.group-icon-edit').hide();
    $("#group-form-edit-name").hide();
    $("#group-form-edit-visibility").hide();

    let groupInfo = await getOneGroup(groupID);
    let groupMembers = await getGroupMembers(groupID);
    let groupMembersFormatted = groupMembers.reduce((out, x) => out += formatMember(x), "");
    let groupAdmin = groupMembers.find(user => user.id == groupInfo.admin);
    let groupAdminFormatted = formatMember(groupAdmin);

    if( groupAdmin.id == currentUser.id ) $("#group-edit").show();
    else $("#group-edit").hide();
    
    $("#group-name").html(groupInfo.name);
    $("#group-visibility").html(`<span>${groupInfo.visibility}</span>`);
    $("#group-admin").html(groupAdminFormatted);
    $("#group-members").html(groupMembersFormatted);
    $('#group-invit-user-btn').attr("data-groupid",groupID);
    $('#group-leave').attr("data-groupid",groupID);

    $('#group-edit').attr("data-groupid",groupID);
    $('#group-input-name').val(groupInfo.name);
    $('#group-edit-name-valid-btn').attr("data-groupid",groupID);
    $('#group-edit-name-reset-btn').attr("data-groupid",groupID);

    $('#group-input-visibility').val( visibilityToID(groupInfo.visibility) );
    $('#group-edit-visibility-valid-btn').attr("data-groupid",groupID);
    $('#group-edit-visibility-reset-btn').attr("data-groupid",groupID);

    let groupMessages = await getGroupMessages(groupID);
    let groupMessagesFormatted = groupMessages.reduce((out, x) => out += formatGroupMessage(x), "");

    $("#group-messages").html(groupMessagesFormatted);
}


/**
 * Active group edition mode
 * @param {*} groupID 
 */
function activeEditGroup(groupID) {
    let admin = (getInfoUserGroup(groupID)).admin;

    $('.group-icon-edit').toggle();

    if(!$('#group-admin').find('.member-item').hasClass('edited')) {
        $('#group-admin').find('.member-item').append(`<button type="button" class="btn btn-primary btn-sm change-admin">Change</button>`);
        $('#group-admin').find('.member-item').addClass('edited');
    } else {
        $('#group-admin').find('.btn').remove();
        $('#group-admin').find('.member-item').removeClass('edited');
    }

    $('#group-members').find('.member-item').each( function() {
        let userID = $(this).attr("data-userid");
        
        if( parseInt(userID) !== admin ) {
            if( !$(this).hasClass("edited") ) {
                $(this).append(`<button type="button" data-groupid=${groupID} data-userid="${userID}" class="btn btn-danger btn-sm remove-user">Remove</button>`);
                $(this).addClass('edited');
            } else {
                $(this).find('.btn').remove();
                $(this).removeClass("edited");
            }
        }
    });

}

/**
 * On click : show group edition mode
 */
$(document).on('click', "#group-edit", function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    activeEditGroup(groupID);
});

/**
 * On click : show user selection for admin modification
 */
$(document).on('click', ".change-admin", function(e) {
    $('#group-members').find('.member-item').each( function() {
        if($(this).find(".btn").hasClass("remove-user")) {
            $(this).find(".btn").text("Select");
            $(this).find(".btn").removeClass("remove-user btn-danger");
            $(this).find(".btn").addClass("select-admin btn-success");
        } else {
            $(this).find(".btn").text("Remove");
            $(this).find(".btn").addClass("remove-user btn-danger");
            $(this).find(".btn").removeClass("select-admin btn-success");
        }
    });
});

/**
 * On click : apply admin modification
 */
$(document).on('click', ".select-admin", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let userID = String(e.target.getAttribute('data-userid'));
    await patchGroup(groupID, {admin:userID});
    await updateUserGroups();
    fillGroupModal(groupID);
});


/**
 * On click : remove user of the group 
 */
$(document).on('click', ".remove-user", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let userID = String(e.target.getAttribute('data-userid'));
    await addRemoveUsersFromGroup(groupID, userID);
    await updateUserGroups();
    await fillGroupModal(groupID);
    activeEditGroup(groupID);
});




// NAME MODIFICATIONS -------------------------

/**
 * Active name modification on group modal
 */
$(document).on('click', "#group-icon-edit-name", function() {
    $("#group-name").hide();
    $('.group-icon-edit').hide();
    $('#group-edit').attr('disabled', 'disabled');
    $("#group-form-edit-name").show()
    $("#group-input-name").focus();
});


/**
 * Check and send new name
 */
$(document).on('click', "#group-edit-name-valid-btn", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let groupInfo = getInfoUserGroup(groupID);
    let value = $("#group-input-name").val();
    let validNewName = false;

    if( value !== "" && value !== groupInfo.name ) {
        await patchGroup(groupID, {name: value}).then( 
            data => { validNewName = true;
                      $("#group-name").html(value);
                      updateUserGroups(); },
            error => { showGroupAlert("Name already exists") } 
        );
    }

    if(!validNewName) {
        $("#group-input-name").val(groupInfo.name);
    }
    $("#group-form-edit-name").hide();
    $('.group-icon-edit').show();
    $('#group-edit').removeAttr("disabled");
    $("#group-name").show();
});

/**
 * Reset name modifications
 */
$(document).on('click', "#group-edit-name-reset-btn", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let groupInfo = getInfoUserGroup(groupID);
    $("#group-input-name").val(groupInfo.name);
    $("#group-form-edit-name").hide();
    $('.group-icon-edit').show();
    $('#group-edit').removeAttr("disabled");
    $("#group-name").show();
});

// VISIBILITY MODIFICATIONS -------------------------

/**
 * Active visibility modification on group modal
 */
$(document).on('click', "#group-icon-edit-visibility", function() {
    $("#group-visibility").hide();
    $('.group-icon-edit').hide();
    $('#group-edit').attr('disabled', 'disabled');
    $("#group-form-edit-visibility").show()
});

/**
 * Check and send new visibility
 */
$(document).on('click', "#group-edit-visibility-valid-btn", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let groupInfo = getInfoUserGroup(groupID);
    let value = $("#group-input-visibility").val();
    let groupVisibility = visibilityToID(groupInfo.visibility);

    if( value !== groupVisibility ) {
        await patchGroup(groupID, {visibility: value}).then( 
            data => { $("#group-visibility").html( IDToVisibility(value) );
                      updateUserGroups();}
        );
    }

    $("#group-form-edit-visibility").hide();
    $('.group-icon-edit').show();
    $('#group-edit').removeAttr("disabled");
    $("#group-visibility").show();
});

/**
 * Reset visibility modifications
 */
$(document).on('click', "#group-edit-visibility-reset-btn", async function(e) {
    let groupID = String(e.target.getAttribute('data-groupid'));
    let groupInfo = getInfoUserGroup(groupID);
    $('#group-input-visibility').val( visibilityToID(groupInfo.visibility) );
    $("#group-form-edit-visibility").hide();
    $('.group-icon-edit').show();
    $('#group-edit').removeAttr("disabled");
    $("#group-visibility").show();
});

/**
 * Convert visibility name in ID
 * @param {*} visibility 
 */
function visibilityToID(visibility) {
    switch(visibility) {
        case "Public": return 1;
        case "Semi-Private": return 2;
        default: return 3
    }
}

/**
 * Coonvert visibility ID in name
 * @param {*} ID 
 */
function IDToVisibility(ID) {
    switch(ID) {
        case "1": return "Public";
        case "2": return "Semi-Private";
        default: return "Private"
    }
}


/**
 * Leave a group is normal user or last member
 */
$(document).on('click', "#group-leave", async function(e){
    let groupID = String(e.target.getAttribute('data-groupid'));
    let currentGroup = getInfoUserGroup( groupID );
    let adminID = currentGroup.admin;
    let groupSize = currentGroup.users.length;
    
    let validExit = (currentUser.id != adminID) || (groupSize == 1)

    if(currentUser.id != adminID)
        await addRemoveUsersFromGroup(groupID, currentUser.id);

    if(groupSize == 1)
        await deleteGroup(groupID);

    if(validExit) {
        updateUserGroups(currentUser.id);
        $("#modal-see-group").modal('hide'); 
    } else {
        showGroupAlert("You must select a new Admin before leaving group")
    }

});


/*
 * Authorize data-attribute in sanitizer whitelist
 */
$.fn.tooltip.Constructor.Default.whiteList['*'].push('data-groupid');
$.fn.tooltip.Constructor.Default.whiteList['*'].push('data-userid');

/*
 * Activate popover and html nesting
 */
$("[data-toggle=popover]")
    .popover({
        html: true,
        title: "<a class='add-group-btn' href='#'><img src='../../static/img/add-button.png'></a>" +
                "&nbsp<a class='join-group-btn' href='#'><img src='../../static/img/join-button.png'></a>"
                 
    });

/*
 * Show group modal on click and hide popover
 */
$(document).on('click', "#group-see-group-btn", function(e){
    let groupID = String(e.target.getAttribute('data-groupid'));
    fillGroupModal(groupID);
    $("#modal-see-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});


/*
 * Join group 
 */
$(document).on('click', "#group-join-group-btn", async function(e){
    let userID = currentUser.id;
    let groupID = String( e.target.getAttribute('data-groupid'));
    let response = await joinGroup(userID, groupID)
    $("#modal-join-group").modal('hide');
    //updateUserGroups(userID);
});


/*
 * Refresh the user group list on click
 */
$(document).on('click', "#btn-group", function() {
    updateUserGroups(currentUser.id);
});

/**
 * Show create group modal on click + and hide popover
 */
$(document).on("click", ".add-group-btn", () => {
    $(".adminNewGroup #adminName").text(currentUser.name);
    $(".membresNewGroup #adminName").text(currentUser.name);
    $("#modal-post-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});

/**
 * Show join group list modal on click + and hide popover
 */
$(document).on("click", ".join-group-btn", async function() {
    let publicGroups = await getPublicGroups();
    let listPublicGroups = "";
    publicGroups.forEach((publicGroup) => {
        listPublicGroups += formatJoinGroup(publicGroup)
    });
    $("#modal-join-group").find(".modal-body").html(listPublicGroups);
    $("#modal-join-group").modal('show');
    $("[data-toggle=popover]").popover('hide');
});

/**
 * Display an alert message on the main screen
 * @param {*} message 
 */
function showAlert(message){
    $(".alert-container").prepend(
        `
        <div id="alert-err" class="alert alert-danger alert-dismissible fade show" role="alert">
            <span class="alert-body">${message}</span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        `
    );
    $(".alert-container .alert").first().delay(2000).fadeOut(1000, function () { $(this).remove(); });
}


/**
 * Create group on form submit 
 */
$("#create_group").submit( () => {
    if($("#nameOfGroup input").val().length > 0) {
        createGroup(
            $("#nameOfGroup input").val(), 
            currentUser.id, 
            $("#create_group #visibility").val()
            );
            $("#modal-post-group").modal('hide');
            $("#create_group")[0].reset();
    }
});

/**
 * Display invit user modal
 */
$(document).on('click', "#group-invit-user-btn", async function(e){
    let groupID = String(e.target.getAttribute('data-groupid'));
    userList = await getUnknowUserListFromGroup(groupID);
    formatInvitUserList(groupID, userList);
    $("#modal-see-group").modal('hide');
    $("#modal-invit-user").modal('show');
});


/**
 * On click : select a user to invit
 */
$(document).on('click', ".item-user-invit-list", function(){
    $(this).toggleClass("active");  
});

/**
 * On click : add invit users to the current group
 */
$(document).on('click', "#invit-users-btn", async function(){
    let userList = [];
    let groupID = $("#search-invit-content").attr("data-usergroup");
    $('#search-invit-content').children().each( function() {
        if( $(this).hasClass('active') )
            userList.push( $(this).attr("data-userid") );
    });
    userList.forEach( async function(user) {
        await addRemoveUsersFromGroup(groupID, parseInt(user));
    });   
    await updateUserGroups();
    await fillGroupModal(groupID);
    $("#modal-invit-user").modal('hide');
    $("#modal-see-group").modal('show'); 
});


/*
 [ Utils ] -------------------------------------------------------------------------------------
 */

/**
 * When the user clicks on the button, toggle between hiding and showing the dropdown content
 */
/* function btn_showUserList() {
    document.getElementById("group_users_list").classList.toggle("show");
} */


/**
 * Function used to filter dropdown search
 */
function filterUserFunction() {
    var input, filter, buttons, i;
    input = document.getElementById("user_search");
    filter = input.value.toUpperCase();
    div = document.getElementById("search-invit-content");
    buttons = div.getElementsByTagName("button");
    for (i = 0; i < buttons.length; i++) {
        txtValue = buttons[i].textContent || buttons[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            buttons[i].style.display = "";
        } else {
            buttons[i].style.display = "none";
        }
    }
}

function showGroupAlert(message){
    $("#group-modal-body").prepend(
        `
        <div id="alert-err" class="alert alert-danger alert-dismissible fade show" role="alert">
            <span class="alert-body">${message}</span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        `
    );
    $("#group-modal-body .alert").first().delay(1000).fadeOut(1000, function () { $(this).remove(); });
}




/* function filterUserFunction() {
    var input, filter, ul, li, a, i;
    input = document.getElementById("group_search");
    filter = input.value.toUpperCase();
    div = document.getElementById("search-content");
    a = div.getElementsByTagName("a");
    for (i = 0; i < a.length; i++) {
        txtValue = a[i].textContent || a[i].innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
            a[i].style.display = "";
        } else {
            a[i].style.display = "none";
        }
    }
} */